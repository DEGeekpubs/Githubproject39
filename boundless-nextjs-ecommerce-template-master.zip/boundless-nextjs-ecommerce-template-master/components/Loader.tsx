export default function Loader() {
	return (
		<div className='loader-page-centered'>
			<div className='lds-facebook'>
				<div></div>
				<div></div>
				<div></div>
			</div>
		</div>
	);
}